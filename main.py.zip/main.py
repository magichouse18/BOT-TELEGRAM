import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, InputMediaPhoto
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes
from flask import Flask
from threading import Thread

# TOKEN DEL BOT
TOKEN = "7829595925:AAFg1zi_RWGPbIEXRTazPuITJso7m36rhpQ"

# Avvia Flask per mantenere attivo su Render
app = Flask(__name__)
@app.route('/')
def home():
    return "Bot attivo!"

def run_flask():
    app.run(host='0.0.0.0', port=8080)

# Costanti per i pulsanti
SHOP, WEED, HASH, EDIBILI, REGOLAMENTO, PAGAMENTI, CONTATTI, GREENPOISON = range(8)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("🛍️ Shop 🛍️", callback_data=str(SHOP))],
        [InlineKeyboardButton("💰 Pagamenti 💰", callback_data=str(PAGAMENTI))],
        [InlineKeyboardButton("🧑‍💻 Contattami 🧑‍💻", callback_data=str(CONTATTI))],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Benvenuti nel nostro Bot Ufficiale.
"
                                    "Il Bot viene costantemente aggiornato con i prodotti disponibili.
"
                                    "Per qualsiasi informazione o ordini contattare: @theitalianfactory_official",
                                    reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    data = int(query.data)

    if data == SHOP:
        keyboard = [
            [InlineKeyboardButton("🌿 WEED 🌿", callback_data=str(WEED))],
            [InlineKeyboardButton("🍫 HASH 🍫", callback_data=str(HASH))],
            [InlineKeyboardButton("🍭 EDIBILI 🍭", callback_data=str(EDIBILI))],
            [InlineKeyboardButton("📜 REGOLAMENTO 📜", callback_data=str(REGOLAMENTO))],
            [InlineKeyboardButton("⬅️ Indietro", callback_data="start")]
        ]
        await query.edit_message_text("Seleziona il tipo di prodotto:", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == WEED:
        keyboard = [
            [InlineKeyboardButton("🇺🇸 CALI USA", callback_data="cali")],
            [InlineKeyboardButton("🌴 GREEN POISON", callback_data=str(GREENPOISON))],
            [InlineKeyboardButton("⬅️ Indietro", callback_data=str(SHOP))]
        ]
        await query.edit_message_text("La nostra selezione WEED:", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == GREENPOISON:
        photo_url = "https://raw.githubusercontent.com/magichouse18/telegram-bot-magichous8/main/assets/greenpoison.jpeg"
        caption = "🌴 GREEN POISON (✅)
🏡 INDOOR

💰PREZZO:
10g👉90€
15g👉125€
20g👉160€
30g👉225€
50g👉375€
100g👉675€
200g👉1300€
500g👉3125€

ℹ️Coltivata in serra, cime belle piene. NO SEMI, cime compatte sia tozze sia lunghe"
        keyboard = [[InlineKeyboardButton("⬅️ Indietro", callback_data=str(WEED))]]
        await query.edit_message_media(media=InputMediaPhoto(media=photo_url, caption=caption),
                                       reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == PAGAMENTI:
        keyboard = [[InlineKeyboardButton("⬅️ Indietro", callback_data="start")]]
        await query.edit_message_text("Info su pagamenti in arrivo.", reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == CONTATTI:
        keyboard = [[InlineKeyboardButton("⬅️ Indietro", callback_data="start")]]
        await query.edit_message_text("Contatta @theitalianfactory_official", reply_markup=InlineKeyboardMarkup(keyboard))

    elif query.data == "start":
        await start(update, context)

def main() -> None:
    app_thread = Thread(target=run_flask)
    app_thread.start()

    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button))

    application.run_polling()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
